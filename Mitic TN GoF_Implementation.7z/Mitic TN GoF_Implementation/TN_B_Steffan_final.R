DEBUG <- FALSE
myprint <- if(DEBUG) print else function(x){return(invisible(NULL))}

#install.packages("truncgof")
library(truncgof)
library(boot)
library(readr)
library(readr)
#emp_l <-  read_csv2("C:/Users/Dominik/Desktop/lossdata.csv")
#attach(emp_l)
set.seed(1)
# myprint <- print
Loss <- rt(5000, 20)
base_mean=mean(Loss)
base_sd =sd(Loss)
p =0.05
R=100

x <- Loss[order(Loss)]
#load("TNBTestdata.Rdata")
#x <- Loss 
emp_l <- x
#base_mean =mean(x)
#base_sd <- sd(x)



#set.seed(123) # gurantess that I get always tge sane result since I have stochastical component (bootstra resample) in this function



  # histogramm (density for discrete empirical values)
  hist(emp_l)

  # empirical cumulative distribution function
  prob_emp=numeric(length(emp_l))
  for(i in 1:length(emp_l)){
    prob_emp[i]= (i)/length(emp_l) # prob_emp = y = Y
  }




  plot(prob_emp~emp_l, type="l")

  #import fitted values in loss space

  prob_fit=numeric(length(emp_l))
  for(i in 1:length(emp_l)){
    prob_fit[i]= pnorm(emp_l[i], mean=base_mean, sd=base_sd) # adapt the fitting distribution, here it is normal
  }
  myprint("prob_fit"); myprint(head(prob_fit))




  plot(emp_l, prob_emp, type="l", col="blue")
  points(emp_l, prob_fit, type = "l",col="red")
  legend(2, 0.2, legend=c("Fitting CDF", "Empirical CDF"),col=c("red", "blue"), lty=1:1, cex=0.8)
  


  # Probability Space


  # Empriical: transform Y=y and X = F(x) = i/N and Y = y = i/N to get 45° line

  emp_p <- prob_emp

  # Fitted probabilites with candidate distribution: transform X = F(x) = Normal Distriubtion Quantiles and Y = y
  #(fit_p <- prob_fit)

  plot(emp_p, prob_emp, type = "l",col="blue")
  points(prob_fit, prob_emp, type = "l", col="red")
  legend(0.6, 0.1, legend=c("Transformed Fitting CDF", "Transformed Empirical CDF"),col=c("red", "blue"), lty=1:1, cex=0.8)
  

  # calculate W[i] as distance of Y[i+1] and [Y_i] on the 45° line

  W =numeric(length(emp_l)-1)
  for(i in 1:length(emp_l)-1){
    W[i]= sqrt(2)*(prob_emp[i+1]-prob_emp[i]) #distance between adjacent points on 45°line is always the same
  }

  # calculate H[i] as distance between transformed fitting distribution and 45° line

  H =numeric(length(emp_l))
  for(i in 1:length(emp_l)){
    H[i]= abs(prob_fit[i]-prob_emp[i])/sqrt(2) #distance between transformed fitting distribution and 45° line
  }

  #H
  ############
  seq<- seq(1:length(emp_l))
  #seq
  plot(seq,H, type="l")
  ############

  # Calculate area between transoformed fitting distribtuion and 45° line by calcualting trapzezium area (a+c)/2 *h ) m*h = A

  A =numeric(length(H)-1)
  for(i in 1:length(H)-1){
    A[i]= abs((H[i]+H[i+1]/2)*W[i]) #Trapezium Area
  }
  #A
  # Calculate total discrepance between tranformed fitting distribution and 45° line
  A_total=sum(A)
  A_total
  myprint("A_total"); myprint(A_total)



  # TN-B Test
  count = 0
  for(i in 1:(R)){
    count[i+1] =(count[i]+2)

  }

  #count

  # calculate set for alternative mean parameters of size 1+R

  set_mean = 0
  for(i in 1:(R+1)){
    set_mean[i] =base_mean*(count[i]/R) # the base_mean is the fitting parameter of the candidate distribution and is not necessarily equal to the mean of the empirical distribution

  }

  #set_mean # here I assume that the fitting parameters of the candidate distribution are equalt to the paramters of the empiricl distribution

  # calculate set for alternative standard deviation parameters of size 1+R
  set_sd = 0
  for(i in 1:(R+1)){
    set_sd[i] =base_sd*(count[i]/R)  # the base_mean is the fitting parameter of the candidate distribution and is not necessarily equal to the mean of the empirical distribution

  }


  #set_sd # here I assume that the fitting parameters of the candidate distribution are equalt to the paramters of the empiricl distribution


  set_all <- cbind(set_mean,set_sd)
  #set_all
  sample_mean =sample(set_all[,1],1+R, replace=TRUE)
  #sample_mean
  sample_sd =sample(set_all[,2],1+R, replace=TRUE)

  set_all <- cbind(sample_mean,sample_sd)
  resample_par <- set_all
 # resample_par




  resample_par <- cbind(sample_mean,sample_sd)
  #resample_par
  myprint("resample_par"); myprint(resample_par)




  #myprint(system.time({
  prob_fit_TNB <- matrix(, nrow= (1+R), ncol=length(emp_l))
  #prob_fit_TNB
  for (i in 1: (1+R)){
    for(m in 1:length(emp_l)){
      prob_fit_TNB[i,m]= pnorm(emp_l[m], mean=resample_par[i, 1], sd=resample_par[i,2])
    }
  }
  #}))

 # prob_fit_TNB
  myprint("prob_fit"); myprint(head(prob_fit_TNB[,1:2]))

  prob_fit <- prob_fit_TNB
  # Fitted probabilites with candidate distribution: transform X = F(x) = Normal Distriubtion Quantiles and Y = y

  emp_p <- prob_emp




  # calculate W[i] as distance of Y[i+1] and [Y_i] on the 45° line

  W =numeric(length(emp_l)-1)
  for(i in 1:length(emp_l)-1){
    W[i]= sqrt(2)*(prob_emp[i+1]-prob_emp[i]) #distance between adjacent points on 45°line is always the same
  }
  #W
  myprint("W"); myprint(head(W))


  # calculate H[i] as distance between transformed fitting distribution and 45° line

  H = matrix(, nrow= (1+R), ncol=length(emp_l))
  for(k in 1:(1+R)){
    for(i in 1:length(emp_l)){
      H[k,i]= abs(prob_fit[k,i]-prob_emp[i])/sqrt(2) #distance between transformed fitting distribution and 45° line
    }
  }


  #H
  myprint("H"); myprint(head(H[,1:5]))


  # Calculate area between transoformed fitting distribtuion and 45° line by calcualting trapzezium area (a+c)/2 *h ) m*h = A

  A = matrix(, nrow= (R+1), ncol=(ncol(H)-1))
  (length(H)-1)
  for (k in 1:(R+1)){

    for(i in 1: (ncol(H)-1)){


      A[k,i]= abs((H[k,i]+H[k,(i+1)]/2)*W[i]) #Trapezium Area
    }
  }

  # Calculate total discrepance between tranformed fitting distribution and 45° line
  #A
  myprint("A"); myprint(head(A[1:5]))

  A_k <- numeric(1+R)
  #A_k
  for(i in 1: (1+R)){
    A_k[i] = sum(A[i,])
  }
  myprint("A_k"); myprint(head(A_k))
  #A_k
  A_mean <- mean(A_k)
  myprint("A_mean"); myprint(A_mean)
  myprint("A_k"); myprint(head(A_k))


  difference<-numeric(length(A_k)) # Calculate the diference between the total mean area of the A_matrix and the mean area of each bootstrap
  for(m in 1:(length(A_k))){

    difference[m] <-abs(A_k[m]-A_mean)
  }
  myprint("difference"); myprint(head(difference))
  #count_difference = 0

  # for(i in 0:((length(A_k)-1))){
  #   if (difference[(i+1)] > A_total){
  #
  #     count_difference= count_difference +1
  #   }
  #
  #
  # }
  # count_difference


 count_difference <- sum(difference>A_total)
  myprint("count_difference"); myprint(head(count_difference))

  # calculate p-value
  p_TNB <- (1+count_difference)/(2+R)
  # H_o set of parameters equals to the pre-defined set of parameters
  if (p_TNB > p){
    print (list("Accept H_0, distribution fits", p_TNB=p_TNB))
  }else{
    print (list("Accept H_1, distribution does not fit", p_TNB=p_TNB))
  }

#print(system.time(source("TN_B_Steffan_final.R")))

#system.time(source("TN_B_Steffan_final.R"))



########TESTS for Control#####
# Reject H_0: F* = F if the p-value is smaller than alpha (level of significance)


#TN_B(emp_l=x, R=4, p=0.05, base_mean=47.46049, base_sd =24.55923, FUN=pnorm)
#qplot(x,"pnorm",list(mean=47, sd=24),H = NA, ylim=c(10,100), xlim=c(10,100) )



