#install.packages("truncgof")
library(truncgof)
library(boot)
library(readr)
lossdata<- read_csv2("C:/Users/Dominik/Desktop/lossdata.csv")
#View(lossdata)
attach(lossdata)

# Loss Space and Probability Space

# emp_l = empirical losses in loss space
# emp_p = empirical losses in probaility setPackageName

#Probability for empirical losses and and fitted losses with distribution candidate
# prob_emp =  probability of empirical losses
# prob_fit = probability of fitted losses by candidate distribution


T=0
p=0.05
# LOSS SPACE

# transform loss data in increasing order of size
Loss <- rt(1000, 50)

base_mean=mean(Loss)
base_sd =sd(Loss)
###
emp_l_all <- Loss[order(Loss)]
emp_l_all

# Define p-value for TN_A
#alpha <- 0.05

# Define function

  # T = Threshold for left truncated loss data
  emp_l <-tail(emp_l_all,(1-T)*length(emp_l_all)) # left truncated empirical data
  emp_l
  n <- length(emp_l)
  # histogramm (density for discrete empirical values)
  hist(emp_l_all)
  hist(emp_l)

  # empirical cumulative distribution function
  prob_emp=numeric(length(emp_l_all)-T*length(emp_l_all))
  for(i in 1:length(emp_l_all)-T*length(emp_l_all)){
    prob_emp[i]= (i+T*length(emp_l_all))/length(emp_l_all) # prob_emp = y = Y
  }
  prob_emp
  emp_l
  emp_l_all




  plot(prob_emp~emp_l, type="l")

  #import fitted values in loss space

  prob_fit=numeric(length(emp_l_all)-T*length(emp_l_all))
  for(i in 1:length(emp_l_all)-T*length(emp_l_all)){
    prob_fit[i]= pnorm(emp_l_all[i+T*length(emp_l_all)], mean=base_mean, sd=base_sd) #FUN
  }
  prob_fit
  prob_emp
  length(prob_fit)==length(prob_emp)


  plot(emp_l, prob_emp, type="l", col="blue")
  points(emp_l, prob_fit, type = "l",col="red")



  # Probability Space


  # Empriical: transform Y=y and X = F(x) = i/N and Y = y = i/N to get 45° line

  emp_p <- prob_emp

  # Fitted probabilites with candidate distribution: transform X = F(x) = Normal Distriubtion Quantiles and Y = y
  #(fit_p <- prob_fit)

  plot(emp_p, prob_emp, type = "l",col="blue")
  points(prob_fit, prob_emp, type = "l", col="red")

  # calculate W[i] as distance of Y[i+1] and [Y_i] on the 45° line

  W =numeric(length(emp_l)-1)
  for(i in 1:length(emp_l)-1){
    W[i]= sqrt(2)*(prob_emp[i+1]-prob_emp[i]) #distance between adjacent points on 45°line is always the same
  }

  # calculate H[i] as distance between transformed fitting distribution and 45° line

  H =numeric(length(emp_l))
  for(i in 1:length(emp_l)){
    H[i]= abs(prob_fit[i]-prob_emp[i])/sqrt(2) #distance between transformed fitting distribution and 45° line
  }

  H
  ############
  seq<- seq(1:length(emp_l))
  seq
  plot(seq,H, type="l")
  ############




  # TN-S-test
  ## Resample H

#boot_mean <- numeric(length(H))
#boot_mean
N <- round(n/4) #number of resapmles

#for (i in 1: N){
#sample <- sample(H, length(H), replace=TRUE)
#boot_mean[i] <- mean(sample)
#
#}
#boot_mean

boot_mean = apply(matrix(sample(H, length(H)*N, replace=TRUE), nrow = N),1, mean)

# Distribution of the mean m as approximation for Mu
measured_mean <- mean(boot_mean)
sd_mean <- sd(boot_mean)
# Test statistic
z_value <- abs((measured_mean)/(sd_mean*sqrt(N)))# H_0: Mu = o

z_value



# critical value form standard normal distribution

z_value_c <- qnorm(1-p/2)

if (z_value < z_value_c){ # If "False", then reject H_0 -> Fitting distribtuion is not adequate enoguh
  print("Accept H_0, distribuiton fits")
}else {
  print("Accept H_1, distribution does not fit")

}


########TESTS for Control#####
# Reject H_0: F* = F if the p-value is smaller than alpha (level of significance)





