#install.packages("truncgof")
library(truncgof)
library(boot)
library(readr)
#lossdata<- read_csv2("C:/Users/domin/Dropbox/privat/Ausbildung/Uni_FIM/1. Semester/Ferienakademie/lossdata.csv")
#View(lossdata)
attach(lossdata)
set.seed(1)
# Loss Space and Probability Space

# emp_l = empirical losses in loss space
# emp_p = empirical losses in probaility setPackageName

#Probability for empirical losses and and fitted losses with distribution candidate
# prob_emp =  probability of empirical losses
# prob_fit = probability of fitted losses by candidate distribution



# LOSS SPACE

# transform loss data in increasing order of size
Loss <-rt(5000, 2)

x <- Loss[order(Loss)]
x

# Define p-value for TN_A
alpha <- 0.05

# Define function

TN_A <- function(emp_l_all=x, p=alpha, base_mean=mean(x), base_sd =sd(x), FUN=pnorm, distn =pnorm, T=0.0){ # base_sd and base_mean are the parameters of the fitting curve
# T = Threshold for left truncated loss data
  emp_l <-tail(emp_l_all,(1-T)*length(emp_l_all)) # left truncated empirical data
  emp_l

  # histogramm (density for discrete empirical values)
  hist(emp_l_all)
  hist(emp_l)

  # empirical cumulative distribution function
  prob_emp=numeric(length(emp_l_all)-T*length(emp_l_all))
  for(i in 1:length(emp_l_all)-T*length(emp_l_all)){
    prob_emp[i]= (i+T*length(emp_l_all))/length(emp_l_all) # prob_emp = y = Y
  }
  prob_emp
  emp_l
  emp_l_all




  plot(prob_emp~emp_l, type="l")

         

  #import fitted values in loss space

  prob_fit=numeric(length(emp_l_all)-T*length(emp_l_all))
  for(i in 1:length(emp_l_all)-T*length(emp_l_all)){
    prob_fit[i]= FUN(emp_l_all[i+T*length(emp_l_all)], mean=base_mean, sd=base_sd) #FUN
  }
  prob_fit
  prob_emp
  length(prob_fit)==length(prob_emp)


  plot(emp_l, prob_emp, type="l", col="blue")
  points(emp_l, prob_fit, type = "l",col="red")
  legend(15, 0.2, legend=c("Fitting CDF", "Empirical CDF"),col=c("red", "blue"), lty=1:1, cex=0.8)
  



  # Probability Space


  # Empriical: transform Y=y and X = F(x) = i/N and Y = y = i/N to get 45° line

  emp_p <- prob_emp

  # Fitted probabilites with candidate distribution: transform X = F(x) = Normal Distriubtion Quantiles and Y = y
  #(fit_p <- prob_fit)

  plot(emp_p, prob_emp, type = "l",col="blue")
  points(prob_fit, prob_emp, type = "l", col="red")
  legend(0.7, 0.2, legend=c("TN Fitting CDF", "TN Empirical CDF"),col=c("red", "blue"), lty=1:1, cex=0.8)
  

  # calculate W[i] as distance of Y[i+1] and [Y_i] on the 45° line

  W =numeric(length(emp_l)-1)
  for(i in 1:length(emp_l)-1){
    W[i]= sqrt(2)*(prob_emp[i+1]-prob_emp[i]) #distance between adjacent points on 45°line is always the same
  }

  # calculate H[i] as distance between transformed fitting distribution and 45° line

  H =numeric(length(emp_l))
  for(i in 1:length(emp_l)){
    H[i]= abs(prob_fit[i]-prob_emp[i])/sqrt(2) #distance between transformed fitting distribution and 45° line
  }

  H
  ############
  seq<- seq(1:length(emp_l))
  seq
  plot(seq,H, type="l")
  ############

  # Calculate area between transoformed fitting distribtuion and 45° line by calcualting trapzezium area (a+c)/2 *h ) m*h = A

  A =numeric(length(H)-1)
  for(i in 1:length(H)-1){
    A[i]= abs((H[i]+H[i+1]/2)*W[i]) #Trapezium Area
  }
  A
  # Calculate total discrepance between tranformed fitting distribution and 45° line
  A_total=sum(A)
 # cat(A_total, "\n")



  # TN-A-test for enclosed Area with H_0: A_total = 0
  ## calculate critical area A_c  for significance level p

  A_c <- 2*sqrt(2)*p*(1-sqrt(2)*p-T) # cp. Mitic (2015), p. 97
  A_c
#  cat(A_c, "\n")

  if (A_total<A_c){ # If "False", then reject H_0 -> Fitting distribtuion is not adequate enoguh
    return(list(Decision="Accept H_0, distribuiton fits", A_c=A_c))
    return(A_c)
  }else {
    return(list(Decision="Accept H_1, distribution does not fit", A_c=A_c, A_total = A_total))


  }
}

########TESTS for Control#####
# Reject H_0: F* = F if the p-value is smaller than alpha (level of significance)
# stats:::t.test.default # Gibt t-test statistik aus


#TN_A(x,0.05,47,22, T=0)
#qplot(x,"pnorm",list(mean=47, sd=22),H = NA, ylim=c(10,100), xlim=c(10,100) )

TN_A()

